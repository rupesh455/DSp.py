import numpy as np 
a = np.array([1,2,3]) 
b = np.array([4,5,6]) 

print("Addition:", a + b) 
print("Multiplication:", a * b) 
print("Mean:", np.mean(a)) 
print("Sum:", np.sum(b)) 
