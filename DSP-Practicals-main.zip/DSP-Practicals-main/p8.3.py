class Node:     
    def __init__(self, data):         
        self.data = data        
        self.next = None  

        class CircularLinkedList:     
            def __init__(self):         
                self.head = None      
                def insert(self, data):         
                    new_node = Node(data)          
                    if not self.head:             
                        self.head = new_node             
                        new_node.next = self.head         
                    else:             
                        temp = self.head             
                        while temp.next != self.head:                 
                            temp = temp.next             
                            temp.next = new_node             
                            new_node.next = self.head      
                            def display(self):         
                                temp = self.head         
                                if self.head:             
                                    while True:                 
                                        print(temp.data, end=" -> ")                 
                                        temp = temp.next                 
                                        if temp == self.head:                     
                                            break         
                                        print("(back to head)")  
                                        cll = CircularLinkedList() 
                                        cll.insert(5) 
                                        cll.insert(10) 
                                        cll.insert(15)
                                        cll.display()
