import math
num = 16
print("Square root:", math.sqrt(num))
print("factorial:", math.factorial(5))
print("Power:", math.pow(2,3))
print("Log:", math.log(10))
